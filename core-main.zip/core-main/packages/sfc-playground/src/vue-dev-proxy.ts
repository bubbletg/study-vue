// serve vue to the iframe sandbox during dev.
export * from 'vue'
